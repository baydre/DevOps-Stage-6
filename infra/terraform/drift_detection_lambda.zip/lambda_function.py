import json
import boto3
import os
import subprocess
import tempfile
import urllib.parse

def lambda_handler(event, context):
    # Initialize clients
    sns = boto3.client('sns')
    s3 = boto3.client('s3')
        
    # Get environment variables
    sns_topic_arn = os.environ['SNS_TOPIC_ARN']
    s3_bucket = os.environ['S3_BUCKET']
    s3_key = os.environ['S3_KEY']
    approval_url = os.environ.get('APPROVAL_URL', 'https://example.com/approve')
    reject_url = os.environ.get('REJECT_URL', 'https://example.com/reject')
        
    # Create a temporary directory for Terraform files
    with tempfile.TemporaryDirectory() as temp_dir:
        # Download Terraform state from S3
        state_file_path = os.path.join(temp_dir, 'terraform.tfstate')
        s3.download_file(s3_bucket, s3_key, state_file_path)
            
        # Change to the temp directory
        os.chdir(temp_dir)
            
        # Create a basic Terraform configuration file
        with open('main.tf', 'w') as f:
            f.write('''
            terraform {
              required_providers {
                aws = {
                  source  = "hashicorp/aws"
                  version = "~> 4.0"
                }
              }
            }
                
            provider "aws" {
              region = "us-east-1"
            }
            ''')
            
        # Initialize Terraform
        subprocess.run(['terraform', 'init'], check=True, capture_output=True)
            
        # Run terraform plan to detect drift
        result = subprocess.run(
            ['terraform', 'plan', '-detailed-exitcode', '-no-color'],
            capture_output=True,
            text=True
        )
            
        # Check if drift was detected (exit code 2)
        if result.returncode == 2:
            # Drift detected
            plan_output = result.stdout
                
            # Create approval/reject URLs with plan output as parameter
            encoded_plan = urllib.parse.quote_plus(plan_output)
            approve_link = f"{approval_url}?plan={encoded_plan}"
            reject_link = f"{reject_url}?plan={encoded_plan}"
                
            # Create email message
            subject = "Terraform Drift Detected - Manual Approval Required"
            message = f"""
            Terraform drift has been detected in your infrastructure.
                
            Plan Output:
            {plan_output}
                
            Please review the changes and take action:
                
            Approve Changes: {approve_link}
            Reject Changes: {reject_link}
                
            The CI/CD pipeline will wait for your approval before proceeding.
            """
                
            # Send notification
            sns.publish(
                TopicArn=sns_topic_arn,
                Subject=subject,
                Message=message
            )
                
            return {
                'statusCode': 200,
                'body': json.dumps('Drift detected and notification sent')
            }
        else:
            # No drift detected
            return {
                'statusCode': 200,
                'body': json.dumps('No drift detected')
            }
